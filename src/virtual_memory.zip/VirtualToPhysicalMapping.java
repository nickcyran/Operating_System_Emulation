
public class VirtualToPhysicalMapping {
	public int physicalPageNumber;
	public int onDiskPageNumber;
	
	public VirtualToPhysicalMapping() {
		physicalPageNumber = -1;
		onDiskPageNumber = -1;
	}
}
